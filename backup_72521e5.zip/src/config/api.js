export const API_BASE_URL = 'http://localhost:8000/api' // Using mock API server
export const API_MOCK_URL = 'http://localhost:3000' // Mock API server